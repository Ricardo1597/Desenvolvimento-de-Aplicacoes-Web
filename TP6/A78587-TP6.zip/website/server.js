var http = require('http')
var url = require('url')
var fs = require('fs')
var pug = require('pug')
var jsonfile = require('jsonfile')

var express = require('express')
var path = require('path')
var app = new express();
app.use(express.static(path.join(__dirname, './Imagens')));

var {parse} = require('querystring')

var myBD = './tarefas.json';

var id = 0;

http.createServer(function(req,res) {

    var purl = url.parse(req.url,true)
    var query = purl.query
    var path  = purl.pathname
    
    console.log('Recebi o pedido: ' + purl.pathname)
    console.log('Com a método: ' + req.method)

    if(req.method == 'GET'){
        if ((path == '/')||(path == '/index')){

            res.writeHead(200,{'Content-Type':'text/html'})
            res.write(pug.renderFile('index.pug'))
            res.end()
        } 
        else if (path == '/registo'){

            res.writeHead(200,{'Content-Type':'text/html'})
            res.write(pug.renderFile('form-tarefa.pug'))
            res.end()
        } 
        else if(path == '/lista'){
            jsonfile.readFile(myBD, (erro,tarefas) => {
                if(!erro){
                    res.writeHead(200,{'Content-Type':'text/html'})
                    res.write(pug.renderFile('lista-tarefas.pug', {lista: tarefas, lixo: false}))
                    res.end()
                }
                else{
                    res.writeHead(200,{'Content-Type':'text/html'})
                    res.write(pug.renderFile('erro.pug', {e: "Erro: na leitura da BD"}))     
                    res.end()
                }
            })
        }
        else if(path == '/lixo'){
            jsonfile.readFile(myBD, (erro,tarefas) => {
                if(!erro){
                    res.writeHead(200,{'Content-Type':'text/html'})
                    res.write(pug.renderFile('lista-tarefas.pug', {lista: tarefas, lixo:true}))
                    res.end()
                }
                else{
                    res.writeHead(200,{'Content-Type':'text/html'})
                    res.write(pug.renderFile('erro.pug', {e: "Erro: na leitura da BD"}))     
                    res.end()
                }
            })
        }
        else if (path == '/w3.css'){

            res.writeHead(200,{'Content-Type':'text/css'})
            fs.readFile('stylesheets/w3.css',(erro,dados)=>{
                if (!erro)
                    res.write(dados)
                else
                    res.write(pug.renderFile('erro.pug', {e: erro}))   
                res.end()

            })
        } 
        else{
            res.writeHead(200,{'Content-Type':'text/html'})
            res.write(pug.renderFile('erro.pug', {e: "Erro: "+path+" não está implementado!"}))
     
            res.end()
        }
    }
    else if(req.method == 'POST'){
        if (path == '/processaForm'){
            recuperaInfo(req, resultado => {
                jsonfile.readFile(myBD, (erro, tarefas)=>{
                    if(!erro){
                        for (var i =0; i < tarefas.length; i++)
                            if (parseInt(tarefas[i].id) === parseInt(resultado.id)) {
                                tarefaRem = tarefas[i]
                                break;
                        }
                        parseTarefa(resultado)
                        resultado.id = tarefas.length
                        tarefas.push(resultado)
                        console.dir(tarefas)
                        jsonfile.writeFile(myBD, tarefas, erro =>{
                            if(erro) console.log('Erro na escrita: ' + erro)
                            else console.log('Registo gravado com sucesso.')
                        })
                        res.end(pug.renderFile('tarefa-adicionada.pug', {tarefa: resultado}))
                    }
                    else res.write(pug.renderFile('erro.pug', {e: "Erro: na leitura da BD"}))  
                })
            })
        }
        else if(path == '/detalhes'){
            recuperaInfo(req, resultado => {
                var tarefaDetalhes = null

                jsonfile.readFile(myBD, (erro, tarefas)=>{
                    if(!erro){
                        for (var i =0; i < tarefas.length; i++)
                            if (parseInt(tarefas[i].id) === parseInt(resultado.id)) {
                                tarefaDetalhes = tarefas[i]
                                break;
                            }
                        console.dir(tarefaDetalhes)

                        if(tarefaDetalhes!=null) res.end(pug.renderFile('tarefa-detalhes.pug', {tarefa: tarefaDetalhes}))
                        else res.write(pug.renderFile('erro.pug', {e: 'Erro na leitura dos detalhes da tarefa.'}))
                    }
                    else res.write(pug.renderFile('erro.pug', {e: "Erro: na leitura da BD"}))     
                })
            })
        }  
        else if (path == '/apagar'){
            recuperaInfo(req, resultado => {
                var tarefaRem = null

                jsonfile.readFile(myBD, (erro, tarefas)=>{
                    if(!erro){
                        for (var i =0; i < tarefas.length; i++)
                            if (parseInt(tarefas[i].id) === parseInt(resultado.id)) {
                                tarefas[i].apagado = true
                                break;
                        }
                        console.dir(tarefas[i])
                        jsonfile.writeFile(myBD, tarefas, erro =>{
                            if(erro) console.log('Erro na escrita: ' + erro)
                            else console.log('Registo apagado com sucesso.')
                        })
                        res.end(pug.renderFile('tarefa-removida.pug', {tarefa: tarefas[i]}))
                    }
                    else res.write(pug.renderFile('erro.pug', {e: "Erro: na leitura da BD"}))     
                })
            })
        }  
        else{
            res.writeHead(200,{'Content-Type':'text/html'})
            res.write(pug.renderFile('erro.pug', {e: "Erro: "+path+" não está implementado!"}))
            res.end()
        }
    }
    else{
        res.writeHead(200,{'Content-Type':'text/html'})
        res.write(pug.renderFile('erro.pug', {e: "Método: "+req.method+" não suportado!"}))     
        res.end()
    }

}).listen(5000,()=>{console.log('Servidor à escuta na porta 5000' )})


function recuperaInfo(request, callback){
    if(request.headers['content-type'] === 'application/x-www-form-urlencoded'){
        let body = ''
        request.on('data', bloco => {
            body += bloco.toString()
        })
        request.on('end', ()=>{
            callback(parse(body))
        })
    }
    else callback(null)
}


function parseTarefa(tarefa){
    var dataAux = new Date()
    var dd = dataAux.getDate();
    var mm = dataAux.getMonth()+1; //January is 0!
    var yyyy = dataAux.getFullYear();

    if(dd<10) dd = '0'+dd
    if(mm<10) mm = '0'+mm

    tarefa.dataReg = dd + '/' + mm + '/' + yyyy

    dataAux = new Date(tarefa.prazo)
    dd = dataAux.getDate();
    mm = dataAux.getMonth()+1; //January is 0!
    yyyy = dataAux.getFullYear();

    if(dd<10) dd = '0'+dd
    if(mm<10) mm = '0'+mm

    tarefa.prazo = dd + '/' + mm + '/' + yyyy
    tarefa.apagado = false
}
