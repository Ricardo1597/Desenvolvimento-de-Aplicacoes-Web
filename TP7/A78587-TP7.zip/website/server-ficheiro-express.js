var express = require('express')
var http = require('http')
var pug = require('pug')
var fs = require('fs')
var formidable = require('formidable')
var logger = require('morgan')
var jsonfile = require('jsonfile')
var path = require("path");

var myBD = './ficheiros.json';

var app = express()

app.use(logger('combined'))
app.use(express.static(path.join(__dirname, '/scripts')));

app.all('/'||'/processaForm'||'/ficheiro',(req,res,next)=>{
    if(req.url != '/w3.css')
        res.writeHead(200, {'Content-Type': 'text/html'})
    next()
})

app.get('/', (req,res)=>{
    jsonfile.readFile(myBD, (erro,ficheiros) => {
        if(!erro){
            res.write(pug.renderFile('index.pug', {lista: ficheiros}))
            res.end()
        }
        else{
            res.write(pug.renderFile('erro.pug', {e: "Erro: na leitura da BD"}))     
            res.end()
        }
    })
})

app.get('/w3.css', (req,res)=>{
    res.writeHead(200,{'Content-Type':'text/css'})
    fs.readFile('stylesheets/w3.css',(erro,dados)=>{
        if (!erro) res.write(dados)
        else res.write(pug.renderFile('erro.pug', {e: erro}))   
        res.end()
    })
})

app.get('/ficheiro/:nome', (req,res)=>{
    res.sendFile(__dirname + '/uploaded/' + req.params.nome)
})

app.get('*',function(req,res){  
    res.redirect('http://localhost:4007/')
    res.end()
})


app.post('/processaForm', (req,res)=>{
    var form = new formidable.IncomingForm()
    form.parse(req, (erro, fields, files)=>{
        console.log(files.ficheiro)
        var fenviado = files.ficheiro.path
        var fnovo = './uploaded/'+files.ficheiro.name

        fs.rename(fenviado, fnovo, erro => {
            if(!erro){
                jsonfile.readFile(myBD, (erro, ficheiros)=>{
                    if(!erro){
                        var fich = {
                            ficheiro: files.ficheiro,
                            desc: fields.desc,
                            id: ficheiros.length,
                            submitDate: fields.submitDate
                        }
                        ficheiros.push(fich)
                        console.dir(ficheiros)
                        jsonfile.writeFile(myBD, ficheiros, erro =>{
                            if(erro) console.log('Erro na escrita: ' + erro)
                            else console.log('Registo gravado com sucesso.')
                        })
                        res.redirect('http://localhost:4007/')
                        res.end()
                    }
                    else{
                        res.write(pug.renderFile('erro.pug', {e: "Erro: na leitura da BD"}))  
                        res.end()
                    }
                })
            }
            else{
                res.write(pug.renderFile('erro.pug', {e: "Ocorreram erros"}))
                res.end()
            }
        })
    })
})


var myserver = http.createServer(app)
    
myserver.listen(4007 ,()=>{
    console.log('Servidor à escuta na porta 4007' )
})


function recuperaInfo(request, callback){
    if(request.headers['content-type'] === 'application/x-www-form-urlencoded'){
        let body = ''
        request.on('data', bloco => {
            body += bloco.toString()
        })
        request.on('end', ()=>{
            callback(parse(body))
        })
    }
    else callback(null)
}