var express = require('express');
var router = express.Router();
var jsonfile = require('jsonfile')
var fs = require('fs')
var formidable = require('formidable')


var myBD = __dirname + '/ficheiros.json'

/* GET home page. */
router.get('/', (req, res, next) => res.render('index'))

router.get('/tabela', (req,res) =>{
	jsonfile.readFile(myBD, (erro,ficheiros)=>{
		if(!erro){
			res.render('lista', {lista:ficheiros})
		}
		else{
			res.render('error', {e:erro})
			console.log("ERRO: Falhou a ler da BD")
		}
	})
})

router.get('*',function(req,res){
    res.redirect('http://localhost:4008/')
    res.end()
})

router.post('/processaForm', (req,res)=>{
    var form = new formidable.IncomingForm()
    form.parse(req, (erro, fields, files)=>{
        console.log(files.ficheiro)
        var fenviado = files.ficheiro.path
        var fnovo = __dirname + '/../public/uploaded/'+files.ficheiro.name

        fs.rename(fenviado, fnovo, erro1 => {
        	console.log('entrei no rename')  

            if(!erro1){
                jsonfile.readFile(myBD, (erro2, ficheiros)=>{
                	console.log('entrei no readFile')  

                    if(!erro2){
                        var fich = {
                            ficheiro: files.ficheiro,
                            desc: fields.desc,
                            id: ficheiros.length,
                            submitDate: fields.submitDate
                        }
                        ficheiros.push(fich)
                        console.dir(ficheiros)
                        jsonfile.writeFile(myBD, ficheiros, erro3 =>{
                        	console.log('entrei no writeFile') 
                            if(erro3){
                            	res.status(500)
                            	res.write('Erro na escrita na BD: ' + erro3)
                            	res.end()
                            } 
                            else console.log('Registo gravado com sucesso.')
                        })
                        res.end()
                    }
                    else{
                    	res.status(500)
                        res.write('Erro: na leitura da BD ' + erro2)  
                        res.end()
                    }
                })
            }
            else{
            	console.log('errou no rename: ' + erro1) 
            	res.status(500)
                res.write('Ocorreram erros no parse do form: ' + erro1)
                res.end()
            }
        })
    })
})

module.exports = router;
