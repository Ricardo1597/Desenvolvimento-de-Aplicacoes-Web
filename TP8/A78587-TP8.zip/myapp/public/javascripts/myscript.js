$(()=>{
	$('#myTable').load('http://localhost:4008/tabela')

	$('#file1').bind('change', function() {
		if (this.files[0].size > 200*1024*1024) {
			alert("Tamanho do ficheiro excedeu o limite de 200MB");
			$('#myForm').trigger("reset");
		}
	})

	$('#myForm').submit(function(e){
		e.preventDefault();

		var currentdate = new Date(); 
		var datetime = currentdate.getDate() + "/"
					+ (currentdate.getMonth()+1)  + "/" 
					+ currentdate.getFullYear() + " @ "  
					+ currentdate.getHours() + ":"  
					+ currentdate.getMinutes() + ":" 
					+ currentdate.getSeconds();
		$('#file1Time').val(datetime);

		var formData = new FormData(this);

		$.ajax({
			url:'/processaForm',
			type:"POST",
			contentType: "application/json",
			data:formData,
			success: data =>{
				var nome = $('#file1').val().split(/\\/).pop();
				var descricao = $('#file1Desc').val();
				var dateTimeNow = $('#file1Time').val();

				$('#myTable').append('<tr><td><a href=\'/uploaded/'+nome+'\'>'+nome+'</a></td><td>'+descricao+'</td><td>'+dateTimeNow+'</td></tr>');
				
				$('#myForm').trigger("reset");

				alert("Ficheiro enviado");
			},
			error: e =>{
				alert('Erro no post: ' + e)
				console.log('Erro no post: ' + e)
			},
			cache: false,
			contentType: false,
			processData: false
		});
	});
});