var http = require('http')
var url = require('url')
var fs = require('fs')
var pug = require('pug')

var puburl = /\/obra\//


http.createServer(function(req,res) {

    var myurl = url.parse(req.url,true)
    var path  = myurl.pathname
    
    

    if ((path == '/')||(path == '/index')) {

        res.writeHead(200,{'Content-Type':'text/html'})
        fs.readFile('index.json',(erro,dados)=>{

            if (!erro)
                res.write(pug.renderFile('index.pug', {ind: JSON.parse(dados)}))
            else
                res.write('<p><b>ERRO: </b>' + erro + '</p>')   
            res.end()

            })
    
    } else if(puburl.test(path)){
        
        res.writeHead(200,{'Content-Type':'text/html'})
        var ficheiro = path.split('/')[2]
        var urlNovo = 'obras-musicais-json/json/' + ficheiro + '.json'

        fs.readFile(urlNovo,(erro,dados)=>{

            if (!erro)
                res.write(pug.renderFile('template.pug', {obra: JSON.parse(dados)}))
            else
                res.write('<p><b>ERRO: </b>' + erro + '</p>')   
            res.end()

            })
    
    } else if(path == '/w3.css'){
        res.writeHead(200,{'Content-Type':'text/css'})
        fs.readFile('estilo/w3.css',(erro,dados)=>{

            if (!erro)
                res.write(dados)
            else
                res.write('<p><b>ERRO: </b>' + erro + '</p>')   
            res.end()

        })

    } else{
        res.writeHead(200,{'Content-Type':'text/html'})
        res.write('<p><b>ERRO, pedido desconhecido:</b>' + path + '</p>')   
        res.end()
    }

}).listen(5000,()=>{console.log('Servidor à escuta na porta 5000' )})
